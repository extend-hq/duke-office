# SmartArt DOCX adapter probes

Five self-contained manual documents cover cached drawing geometry, authoritative saved text, inherited run formatting, namespace aliases, empty group transforms, picture fills, a line connector, and semantic-only fallback.

The normal, empty-group-transform, and namespace-alias variants should render identically. The styled cached label inherits Arial, 24pt, bold, and color #A52A65. Cached text takes precedence over semantic associations. Missing and empty cached text bodies stay empty, including associated connector and picture shapes. The semantic-only document should display two labels without invented layout.

The separate text-transform variant requests 90-degree independent text rotation. The shared reader preserves its offset, extent, rotation, and flips; the DOCX adapter renders the saved text frame independently of shape paint. Incomplete text frames still report a fallback warning.

Native Word opening, editing, and visual results remain unmeasured. Parser smoke and schema-metadata receipts are stored separately when validation is run; they do not establish Word parity.

Regenerate with `/usr/bin/python3 scripts/image-fidelity/generate_smartart_docx.py --output artifacts/office-art-fixtures-20261105/smartart`.
