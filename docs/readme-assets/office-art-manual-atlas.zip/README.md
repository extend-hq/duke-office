# OfficeArt manual fixture atlas

Editable Word documents for manual opening, modification, save/reopen, parser inspection and visual comparison. This is a feature catalog, not a full-parity certification.

| Pack | Cases | Planned pages |
| --- | ---: | ---: |
| [office-art-wordart.docx](office-art-wordart.docx) | 68 | 17 |
| [office-art-geometry.docx](office-art-geometry.docx) | 201 | 51 |
| [office-art-fills-outlines.docx](office-art-fills-outlines.docx) | 95 | 24 |
| [office-art-effects.docx](office-art-effects.docx) | 58 | 15 |
| [office-art-three-d.docx](office-art-three-d.docx) | 118 | 30 |
| [office-art-artistic.docx](office-art-artistic.docx) | 30 | 8 |
| [office-art-groups-legacy.docx](office-art-groups-legacy.docx) | 19 | 5 |

Pages use four labeled cells by default. Page numbers are planned from explicit breaks; native pagination has not been measured. Record observations in `review.csv`; manifest IDs locate the exact document/page/cell and generation parameters.

## Coverage labels

- **supported**: An implementation path exists; this fixture has not been compared with native Word.
- **preserved**: Source markup or cached appearance is retained; regeneration is not implemented.
- **fallback**: A simplified appearance or original bitmap is expected; the feature is not fully rendered.
- **unmeasured**: Implementation coverage has not been established for this combination.

All new cases have `measurement: unmeasured`. A supported label means an existing code path, not a successful pixel comparison. Source preservation is based on the package/source-XML path and is not proof of normalized model round-trip fidelity.

## Artistic-effect cache probes

The artistic pack embeds both an original and an unchanged cached bitmap. Effect parameters are editable metadata. Word may trust the cache until an effect is changed or regenerated; identical pictures do not establish that an effect is unsupported. Change a parameter in Word, save, and compare the resulting cached media and rendering. No fake processed cache is supplied.

## Reproduce or select

```sh
/usr/bin/python3 scripts/image-fidelity/generate_office_art_atlas.py --output artifacts/office-art-fixtures-20261105
/usr/bin/python3 scripts/image-fidelity/generate_office_art_atlas.py --families wordart,artistic --output /tmp/office-art-selected
/usr/bin/python3 scripts/image-fidelity/generate_office_art_atlas.py --cases 'wordart/textWave*' --per-page 1 --output /tmp/office-art-waves
```

Requires Python and Pillow, as does the existing image-fidelity generator. No network access is needed to regenerate. ZIP timestamps, media, IDs, catalogs and case ordering are deterministic. Existing output is protected unless `--overwrite` is supplied.

## Validation and limits

Generation checks ZIP integrity, XML well-formedness, internal relationship targets, drawing IDs and selected preset enumerations. It does not run a complete OOXML validator, native Word, or a visual pagination check. No external relationships, macros or OLE payloads are included.

The full generator catalog covers all 41 text-warp and 187 geometry enum values, all 54 pattern and 11 dash presets, all 62 camera, 27 lighting, 15 material and 12 bevel presets, all 20 preset shadows, and all 27 Office 2010 picture-effect extension choices, with selected parameter and combination edges. The pack table above describes the current selection. The catalog does not exhaust parameter products, invalid markup, binary DOC records, codecs, SmartArt, charts, ink, media/OLE, arbitrary font shaping, or every Office version. Existing picture/effect-order/group matrices remain separate references.

## Primary schema sources

- https://github.com/dotnet/Open-XML-SDK/blob/main/data/schemas/schemas_openxmlformats_org_drawingml_2006_main.json
- https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.drawing.textshapevalues?view=openxml-3.0.1
- https://learn.microsoft.com/en-us/openspecs/office_standards/ms-odrawxml/869af0ef-665b-4f28-a596-0917474ede26
- https://learn.microsoft.com/en-us/openspecs/office_standards/ms-odrawxml/987a3a42-96d7-4aff-ad43-fb600752011e
